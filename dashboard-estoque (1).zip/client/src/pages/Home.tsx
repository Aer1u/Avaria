import { DataTable } from '@/components/DataTable';
import { FilterPanel } from '@/components/FilterPanel';
import { SearchBar } from '@/components/SearchBar';
import { StatCard } from '@/components/StatCard';
import { ExportButton } from '@/components/ExportButton';
import { useEstoqueData } from '@/hooks/useEstoqueData';
import { formatNumber } from '@/lib/formatters';
import { AlertCircle, Package, Warehouse, MapPin, BarChart3, TrendingUp } from 'lucide-react';
import { useMemo } from 'react';

/**
 * Dashboard Minimalista Corporativo
 * Design: Azul Profundo + Cinza | Tipografia: Poppins (heads) + Inter (body)
 * Layout: Estatísticas no topo, tabela de dados, busca e filtros no final (sticky)
 */
export default function Home() {
  const { data, loading, error, filteredData, searchTerm, setSearchTerm, filters, setFilters, stats } =
    useEstoqueData();

  // Extrair opções únicas para filtros
  const capacidadeOptions = useMemo(
    () => Array.from(new Set(data.map((r) => String(r['Capacidade'])))).sort(),
    [data]
  );

  const nivelOptions = useMemo(
    () =>
      Array.from(new Set(data.flatMap((r) => String(r['Nivel']).split(',').map((n) => n.trim()))))
        .filter((n) => n !== '')
        .sort(),
    [data]
  );

  // Calcular estatísticas adicionais
  const additionalStats = useMemo(() => {
    const driveCount = data.filter((r) => r['Drive Misturado'] === 'Sim').length;
    const utilizacaoMedia = data.length > 0
      ? Math.round(
          data.reduce((sum, r) => sum + (r['Quantidade Total'] / r['Capacidade']), 0) / data.length * 100
        )
      : 0;

    return {
      driveCount,
      utilizacaoMedia,
    };
  }, [data]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header Simples */}
      <header className="bg-card border-b border-border shadow-sm">
        <div className="container py-6">
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-foreground font-poppins">
                Dashboard de Estoque
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Gestão centralizada de paletes e produtos em tempo real
              </p>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-100 text-green-800 text-sm font-medium">
              <span className="w-2 h-2 rounded-full bg-green-600 animate-pulse"></span>
              Sistema Ativo
            </div>
          </div>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <main className="container py-8">
        {/* Mensagem de Erro */}
        {error && (
          <div className="mb-6 p-4 rounded-lg bg-red-50 border border-red-200 flex gap-3">
            <AlertCircle className="text-red-600 flex-shrink-0" size={20} />
            <div>
              <p className="font-semibold text-red-800">Erro ao carregar dados</p>
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        )}

        {/* Cards de Estatísticas */}
        {!loading && !error && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatCard
              label="Total de Paletes"
              value={formatNumber(stats.totalPaletes)}
              icon={<Package size={20} />}
              description="Quantidade total de paletes"
            />
            <StatCard
              label="Quantidade Total"
              value={formatNumber(stats.totalQuantidade)}
              icon={<Warehouse size={20} />}
              description="Itens em estoque"
            />
            <StatCard
              label="Posições Cadastradas"
              value={formatNumber(stats.posicoesCadastradas)}
              icon={<MapPin size={20} />}
              description="Capacidade total disponível"
            />
            <StatCard
              label="Utilização Média"
              value={`${additionalStats.utilizacaoMedia}%`}
              icon={<TrendingUp size={20} />}
              description="Capacidade média utilizada"
            />
          </div>
        )}

        {/* Seção de Resultados */}
        <div className="space-y-4 mb-8">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h2 className="text-xl font-bold text-foreground font-poppins">
                Registros de Estoque
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                {loading ? 'Carregando...' : `${filteredData.length} de ${data.length} registros`}
              </p>
            </div>
            <ExportButton data={filteredData} disabled={loading} />
          </div>

          {/* Tabela de Dados */}
          <div className="bg-card rounded-lg border border-border overflow-hidden">
            <DataTable data={filteredData} loading={loading} />
          </div>
        </div>

        {/* Seção de Busca e Filtros - NO FINAL (STICKY) */}
        <div className="sticky bottom-0 bg-gradient-to-t from-background via-background to-transparent pt-8 pb-4 z-30">
          <div className="bg-card rounded-lg border border-border p-6 shadow-lg">
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-3 font-poppins">
                  🔍 Buscar e Filtrar
                </h3>
                <SearchBar value={searchTerm} onChange={setSearchTerm} />
              </div>

              <div className="flex justify-center">
                <FilterPanel
                  filters={filters}
                  onFilterChange={setFilters}
                  capacidadeOptions={capacidadeOptions}
                  nivelOptions={nivelOptions}
                />
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card mt-12">
        <div className="container py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <p>Dashboard de Estoque © 2026 | Dados carregados de arquivo local</p>
            <p className="text-xs">Última atualização: {new Date().toLocaleDateString('pt-BR')}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
