/**
 * Formata um número com separador de milhar
 * Exemplo: 22785 -> "22.785"
 */
export function formatNumber(value: number | string): string {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (isNaN(num)) return '0';
  
  return num.toLocaleString('pt-BR');
}

/**
 * Formata um número para moeda brasileira
 * Exemplo: 1234.56 -> "R$ 1.234,56"
 */
export function formatCurrency(value: number | string): string {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (isNaN(num)) return 'R$ 0,00';
  
  return num.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
}

/**
 * Formata um número com decimais
 * Exemplo: 1234.567 -> "1.234,57"
 */
export function formatDecimal(value: number | string, decimals = 2): string {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (isNaN(num)) return '0,00';
  
  return num.toLocaleString('pt-BR', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

/**
 * Formata um número como percentual
 * Exemplo: 0.856 -> "85,6%"
 */
export function formatPercent(value: number, decimals = 1): string {
  return (value * 100).toLocaleString('pt-BR', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }) + '%';
}

/**
 * Arredonda um número para o inteiro mais próximo
 */
export function roundNumber(value: number): number {
  return Math.round(value);
}
