import { Search, X } from 'lucide-react';
import { useEffect, useState, useCallback } from 'react';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  onSearch?: (value: string) => void;
}

export function SearchBar({
  value,
  onChange,
  placeholder = 'Pesquisar por produto, posição ou palete...',
  onSearch,
}: SearchBarProps) {
  const [isFocused, setIsFocused] = useState(false);
  const [isSearching, setIsSearching] = useState(false);

  // Debounce para busca
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsSearching(false);
      if (onSearch) {
        onSearch(value);
      }
    }, 300);

    if (value) {
      setIsSearching(true);
    }

    return () => clearTimeout(timer);
  }, [value, onSearch]);

  const handleClear = useCallback(() => {
    onChange('');
    setIsSearching(false);
  }, [onChange]);

  return (
    <div className="relative w-full">
      <div
        className={`
          relative flex items-center gap-3 px-4 py-3 rounded-lg
          bg-card border border-border transition-all duration-200
          ${isFocused ? 'ring-2 ring-primary shadow-md border-primary' : 'shadow-sm'}
        `}
      >
        <Search
          size={18}
          className={`text-muted-foreground transition-all duration-200 ${
            isFocused || value ? 'text-primary' : ''
          } ${isSearching ? 'animate-pulse' : ''}`}
        />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder={placeholder}
          className="
            flex-1 bg-transparent outline-none text-foreground placeholder-muted-foreground
            text-sm font-inter
          "
        />
        {value && (
          <button
            onClick={handleClear}
            className="
              p-1 rounded hover:bg-secondary transition-colors duration-150
              text-muted-foreground hover:text-foreground
            "
            aria-label="Limpar busca"
            type="button"
          >
            <X size={16} />
          </button>
        )}
      </div>
      {value && (
        <p className="text-xs text-muted-foreground mt-2">
          {isSearching ? 'Buscando...' : 'Pressione Enter ou aguarde para buscar'}
        </p>
      )}
    </div>
  );
}
