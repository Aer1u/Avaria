import { EstoqueRecord } from '@/hooks/useEstoqueData';
import { ChevronDown, AlertCircle } from 'lucide-react';
import { useState } from 'react';

interface DataTableProps {
  data: EstoqueRecord[];
  loading: boolean;
}

export function DataTable({ data, loading }: DataTableProps) {
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

  const toggleRow = (key: string) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(key)) {
      newExpanded.delete(key);
    } else {
      newExpanded.add(key);
    }
    setExpandedRows(newExpanded);
  };

  // Calcular percentual de utilização
  const getUtilizacao = (quantidade: number, capacidade: number) => {
    if (capacidade === 0) return 0;
    return Math.round((quantidade / capacidade) * 100);
  };

  // Determinar cor do indicador de utilização
  const getUtilizacaoColor = (percentual: number) => {
    if (percentual >= 90) return 'bg-red-500';
    if (percentual >= 70) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Nenhum resultado encontrado</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {data.map((record, index) => {
        const utilizacao = getUtilizacao(record['Quantidade Total'], record['Capacidade']);
        const rowKey = `${record['Posição atual']}-${index}`;
        const isExpanded = expandedRows.has(rowKey);

        return (
          <div
            key={rowKey}
            className="border border-border rounded-lg overflow-hidden hover:shadow-md transition-shadow duration-200"
          >
            {/* Header da linha */}
            <button
              onClick={() => toggleRow(rowKey)}
              className="
                w-full px-4 py-3 flex items-center justify-between
                bg-card hover:bg-secondary transition-colors duration-150
                text-left
              "
            >
              <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-4">
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground font-medium">Posição</p>
                  <p className="font-medium text-foreground truncate">{record['Posição atual']}</p>
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground font-medium">Produto</p>
                  <p className="font-medium text-foreground truncate">{record['Produto']}</p>
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground font-medium">Quantidade</p>
                  <p className="font-medium text-foreground">{record['Quantidade Total']}</p>
                </div>
                <div className="min-w-0 hidden lg:block">
                  <p className="text-xs text-muted-foreground font-medium">Utilização</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                      <div
                        className={`h-full ${getUtilizacaoColor(utilizacao)} transition-all duration-300`}
                        style={{ width: `${Math.min(utilizacao, 100)}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium text-foreground whitespace-nowrap">{utilizacao}%</span>
                  </div>
                </div>
              </div>
              <ChevronDown
                size={18}
                className={`text-muted-foreground transition-transform duration-200 ml-2 flex-shrink-0 ${
                  isExpanded ? 'rotate-180' : ''
                }`}
              />
            </button>

            {/* Conteúdo expandido */}
            {isExpanded && (
              <div className="px-4 py-4 bg-secondary border-t border-border">
                <div className="space-y-4">
                  {/* Indicador de utilização em mobile */}
                  <div className="lg:hidden">
                    <p className="text-xs text-muted-foreground font-medium mb-2">Utilização de Capacidade</p>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-3 bg-background rounded-full overflow-hidden">
                        <div
                          className={`h-full ${getUtilizacaoColor(utilizacao)} transition-all duration-300`}
                          style={{ width: `${Math.min(utilizacao, 100)}%` }}
                        />
                      </div>
                      <span className="text-sm font-bold text-foreground whitespace-nowrap">{utilizacao}%</span>
                    </div>
                  </div>

                  {/* Aviso de capacidade */}
                  {utilizacao >= 90 && (
                    <div className="flex gap-2 p-3 rounded-lg bg-red-50 border border-red-200">
                      <AlertCircle size={16} className="text-red-600 flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-red-700">Capacidade crítica! Considere realocar itens.</p>
                    </div>
                  )}

                  {/* Grid de detalhes */}
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-xs text-muted-foreground font-medium mb-1">Nível</p>
                      <p className="text-foreground font-medium">{record['Nivel']}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium mb-1">Profundidade</p>
                      <p className="text-foreground font-medium">{record['Profundidade']}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium mb-1">Qtd. por Palete</p>
                      <p className="text-foreground font-medium">{record['Quantidade/palete']}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium mb-1">ID Palete</p>
                      <p className="text-foreground font-medium">{record['ID Palete'] || '-'}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium mb-1">Qtd. de Palete</p>
                      <p className="text-foreground font-medium">{record['Qtd. de Palete']}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium mb-1">Drive Misturado</p>
                      <div className="flex items-center gap-1">
                        <span className={`inline-block w-2 h-2 rounded-full ${
                          record['Drive Misturado'] === 'Sim' ? 'bg-blue-500' : 'bg-gray-300'
                        }`}></span>
                        <p className="text-foreground font-medium">{record['Drive Misturado'] || '-'}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium mb-1">Data de Alteração</p>
                      <p className="text-foreground font-medium">{record['Data de Alteração']}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium mb-1">Capacidade</p>
                      <p className="text-foreground font-medium">{record['Capacidade']}</p>
                    </div>
                    {record['Obsevarção'] && (
                      <div className="md:col-span-3">
                        <p className="text-xs text-muted-foreground font-medium mb-1">Observação</p>
                        <p className="text-foreground italic">{record['Obsevarção']}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
