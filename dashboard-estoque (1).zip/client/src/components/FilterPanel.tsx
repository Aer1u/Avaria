import { ChevronDown, RotateCcw } from 'lucide-react';
import { useState } from 'react';

interface FilterPanelProps {
  filters: {
    capacidade: string;
    nivel: string;
    driveMisturado: string;
  };
  onFilterChange: (filters: any) => void;
  capacidadeOptions: string[];
  nivelOptions: string[];
}

export function FilterPanel({
  filters,
  onFilterChange,
  capacidadeOptions,
  nivelOptions,
}: FilterPanelProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleFilterChange = (key: string, value: string) => {
    onFilterChange({
      ...filters,
      [key]: value,
    });
  };

  const handleResetFilters = () => {
    onFilterChange({
      capacidade: '',
      nivel: '',
      driveMisturado: '',
    });
  };

  const hasActiveFilters = Object.values(filters).some((v) => v !== '');
  const activeFilterCount = Object.values(filters).filter((v) => v !== '').length;

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`
          flex items-center gap-2 px-4 py-2.5 rounded-lg
          border transition-all duration-200 font-medium text-sm
          ${
            hasActiveFilters
              ? 'bg-primary text-primary-foreground border-primary shadow-md hover:shadow-lg'
              : 'bg-card border-border hover:border-primary text-foreground hover:bg-secondary'
          }
        `}
      >
        <span>Filtros</span>
        {hasActiveFilters && (
          <span className="flex items-center justify-center w-5 h-5 rounded-full bg-primary-foreground text-primary text-xs font-bold">
            {activeFilterCount}
          </span>
        )}
        <ChevronDown
          size={16}
          className={`transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>

      {isOpen && (
        <>
          {/* Overlay */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />

          {/* Painel de Filtros */}
          <div className="
            absolute top-full left-0 mt-2 w-72 bg-card border border-border rounded-lg
            shadow-xl p-4 space-y-4 z-50
          ">
            {/* Filtro Capacidade */}
            <div>
              <label className="text-sm font-semibold text-foreground block mb-2">
                Capacidade
              </label>
              <select
                value={filters.capacidade}
                onChange={(e) => handleFilterChange('capacidade', e.target.value)}
                className="
                  w-full px-3 py-2 rounded-lg border border-border bg-secondary
                  text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary
                  transition-all duration-150
                "
              >
                <option value="">Todas as capacidades</option>
                {capacidadeOptions.map((opt) => (
                  <option key={opt} value={opt}>
                    Capacidade {opt}
                  </option>
                ))}
              </select>
            </div>

            {/* Filtro Nível */}
            <div>
              <label className="text-sm font-semibold text-foreground block mb-2">
                Nível
              </label>
              <select
                value={filters.nivel}
                onChange={(e) => handleFilterChange('nivel', e.target.value)}
                className="
                  w-full px-3 py-2 rounded-lg border border-border bg-secondary
                  text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary
                  transition-all duration-150
                "
              >
                <option value="">Todos os níveis</option>
                {nivelOptions.map((opt) => (
                  <option key={opt} value={opt}>
                    Nível {opt}
                  </option>
                ))}
              </select>
            </div>

            {/* Filtro Drive Misturado */}
            <div>
              <label className="text-sm font-semibold text-foreground block mb-2">
                Drive Misturado
              </label>
              <select
                value={filters.driveMisturado}
                onChange={(e) => handleFilterChange('driveMisturado', e.target.value)}
                className="
                  w-full px-3 py-2 rounded-lg border border-border bg-secondary
                  text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary
                  transition-all duration-150
                "
              >
                <option value="">Todos</option>
                <option value="Sim">Sim</option>
                <option value="Não">Não</option>
              </select>
            </div>

            {/* Divisor */}
            {hasActiveFilters && <div className="h-px bg-border" />}

            {/* Botões de Ação */}
            {hasActiveFilters && (
              <button
                onClick={handleResetFilters}
                className="
                  w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm font-medium
                  bg-secondary text-foreground hover:bg-muted transition-colors duration-150
                "
              >
                <RotateCcw size={14} />
                Limpar Filtros
              </button>
            )}
          </div>
        </>
      )}
    </div>
  );
}
