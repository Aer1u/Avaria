import { ReactNode } from 'react';

interface StatCardProps {
  label: string;
  value: string | number;
  icon: ReactNode;
  description?: string;
  trend?: 'up' | 'down' | 'neutral';
}

export function StatCard({ label, value, icon, description, trend = 'neutral' }: StatCardProps) {
  return (
    <div className="
      bg-card border border-border rounded-lg p-6
      shadow-sm hover:shadow-md transition-shadow duration-200
      flex flex-col gap-3
    ">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-muted-foreground mb-1">{label}</p>
          <p className="text-2xl font-bold text-foreground font-poppins">{value}</p>
        </div>
        <div className="
          p-2 rounded-lg bg-secondary text-primary
          flex items-center justify-center
        ">
          {icon}
        </div>
      </div>
      {description && (
        <p className="text-xs text-muted-foreground">{description}</p>
      )}
    </div>
  );
}
