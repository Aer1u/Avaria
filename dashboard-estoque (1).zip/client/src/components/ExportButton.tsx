import { Download, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { EstoqueRecord } from '@/hooks/useEstoqueData';
import { useExportData } from '@/hooks/useExportData';

interface ExportButtonProps {
  data: EstoqueRecord[];
  disabled?: boolean;
}

export function ExportButton({ data, disabled = false }: ExportButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { exportToCSV, exportToJSON } = useExportData();

  const handleExportCSV = () => {
    const timestamp = new Date().toISOString().split('T')[0];
    exportToCSV(data, `estoque-${timestamp}.csv`);
    setIsOpen(false);
  };

  const handleExportJSON = () => {
    const timestamp = new Date().toISOString().split('T')[0];
    exportToJSON(data, `estoque-${timestamp}.json`);
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        disabled={disabled || data.length === 0}
        className={`
          flex items-center gap-2 px-4 py-2.5 rounded-lg
          border transition-all duration-200 font-medium text-sm
          ${
            disabled || data.length === 0
              ? 'opacity-50 cursor-not-allowed bg-card border-border text-muted-foreground'
              : 'bg-card border-border text-foreground hover:border-primary hover:bg-secondary'
          }
        `}
      >
        <Download size={16} />
        <span>Exportar</span>
        <ChevronDown
          size={16}
          className={`transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>

      {isOpen && (
        <>
          {/* Overlay */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />

          {/* Menu de Exportação */}
          <div className="
            absolute top-full right-0 mt-2 w-48 bg-card border border-border rounded-lg
            shadow-xl p-2 z-50
          ">
            <button
              onClick={handleExportCSV}
              className="
                w-full text-left px-3 py-2 rounded text-sm
                hover:bg-secondary transition-colors duration-150
                text-foreground font-medium
              "
            >
              📊 Exportar como CSV
            </button>
            <button
              onClick={handleExportJSON}
              className="
                w-full text-left px-3 py-2 rounded text-sm
                hover:bg-secondary transition-colors duration-150
                text-foreground font-medium
              "
            >
              📄 Exportar como JSON
            </button>
          </div>
        </>
      )}
    </div>
  );
}
