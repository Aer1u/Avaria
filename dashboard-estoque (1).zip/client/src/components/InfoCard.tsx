import { ReactNode } from 'react';

interface InfoCardProps {
  title: string;
  value: string | number;
  icon?: ReactNode;
  subtitle?: string;
  highlight?: boolean;
}

export function InfoCard({ title, value, icon, subtitle, highlight = false }: InfoCardProps) {
  return (
    <div
      className={`
        rounded-lg p-4 border transition-all duration-200
        ${
          highlight
            ? 'bg-primary/5 border-primary/20 hover:border-primary/40'
            : 'bg-card border-border hover:border-primary/20'
        }
      `}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{title}</p>
          <p className={`text-lg font-bold mt-1 ${highlight ? 'text-primary' : 'text-foreground'}`}>
            {value}
          </p>
          {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
        </div>
        {icon && <div className="flex-shrink-0 text-muted-foreground">{icon}</div>}
      </div>
    </div>
  );
}
