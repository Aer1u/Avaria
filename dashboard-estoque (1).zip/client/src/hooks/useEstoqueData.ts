import { useEffect, useState, useMemo } from 'react';

export interface EstoqueRecord {
  'Posição atual': string;
  'Capacidade': number;
  'Produto': string;
  'Quantidade/palete': number;
  'Nivel': string;
  'Profundidade': string;
  'Quantidade Total': number;
  'Drive Misturado': string | null;
  'ID Palete': string | null;
  'Qtd. de Palete': number;
  'Data de Alteração': string;
  'Obsevarção': string | null;
}

export interface UseEstoqueDataResult {
  data: EstoqueRecord[];
  loading: boolean;
  error: string | null;
  filteredData: EstoqueRecord[];
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  filters: {
    capacidade: string;
    nivel: string;
    driveMisturado: string;
  };
  setFilters: (filters: any) => void;
  stats: {
    totalPaletes: number;
    totalQuantidade: number;
    capacidadeMedia: number;
    posicoesCadastradas: number;
  };
}

export function useEstoqueData(): UseEstoqueDataResult {
  const [data, setData] = useState<EstoqueRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    capacidade: '',
    nivel: '',
    driveMisturado: '',
  });

  // Carregar dados do arquivo JSON
  useEffect(() => {
    const loadData = async () => {
      try {
        const response = await fetch('/dados-estoque.json');
        if (!response.ok) {
          throw new Error('Falha ao carregar dados');
        }
        const jsonData = await response.json();
        setData(jsonData);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Erro desconhecido');
        setData([]);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  // Filtrar dados baseado em busca e filtros
  const filteredData = useMemo(() => {
    return data.filter((record) => {
      // Filtro de busca
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch =
        searchTerm === '' ||
        String(record['Produto']).toLowerCase().includes(searchLower) ||
        String(record['Posição atual']).toLowerCase().includes(searchLower) ||
        String(record['ID Palete']).toLowerCase().includes(searchLower);

      // Filtro de capacidade
      const matchesCapacidade =
        filters.capacidade === '' ||
        String(record['Capacidade']) === filters.capacidade;

      // Filtro de nível
      const matchesNivel =
        filters.nivel === '' ||
        String(record['Nivel']).includes(filters.nivel);

      // Filtro de drive misturado
      const matchesDrive =
        filters.driveMisturado === '' ||
        String(record['Drive Misturado']) === filters.driveMisturado;

      return matchesSearch && matchesCapacidade && matchesNivel && matchesDrive;
    });
  }, [data, searchTerm, filters]);

  // Calcular estatísticas
  const stats = useMemo(() => {
    const totalPaletes = Math.round(data.reduce((sum, r) => sum + (r['Qtd. de Palete'] || 0), 0));
    const totalQuantidade = data.reduce((sum, r) => sum + (r['Quantidade Total'] || 0), 0);
    const capacidadeMedia =
      data.length > 0
        ? Math.round(data.reduce((sum, r) => sum + (r['Capacidade'] || 0), 0) / data.length)
        : 0;
    
    // Posições cadastradas = número de posições únicas × capacidade média
    const posicoesUnicas = Array.from(new Set(data.map((r) => r['Posição atual']))).length;
    const posicoesCadastradas = posicoesUnicas * capacidadeMedia;

    return {
      totalPaletes,
      totalQuantidade,
      capacidadeMedia,
      posicoesCadastradas,
    };
  }, [data]);

  return {
    data,
    loading,
    error,
    filteredData,
    searchTerm,
    setSearchTerm,
    filters,
    setFilters,
    stats,
  };
}
